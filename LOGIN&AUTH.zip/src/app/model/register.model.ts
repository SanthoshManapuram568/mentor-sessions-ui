export class RegisterUser{
    id : String;
    firstName : String;
    lastName : String;
    password : String;
    email : string;
    contact : String;

    constructor(firstName: String,lastName : String,password: String,email: string,contact:String){
        this.firstName=firstName;
        this.lastName= lastName;
        this.password= password;
        this.email= email;
        this.contact=contact;
    }

}