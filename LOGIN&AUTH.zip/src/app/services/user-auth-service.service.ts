import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { LoginUser } from '../model/loginUser.model';

const URL = "http://localhost:3000/users";

@Injectable({
  providedIn: 'root'
})
export class UserAuthServiceService {

  constructor(public http : HttpClient) { }

  // login(details : LoginUser):any{
  //   return this.http.post(URL,details).pipe(
  //     map((successData : Response)=>{
  //       return successData;
  //     }),
  //     map(failureData=>{
  //       return failureData;
  //     })
  //   );
  // }

  login1() : any{
    return this.http.get(URL);
  }

}
