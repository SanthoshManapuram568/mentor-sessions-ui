import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  name1 : string="";
  myFormGroup : FormGroup;
  constructor(formBuilder : FormBuilder) {
    this.myFormGroup= formBuilder.group({
      "firstName":new FormControl(""),
      "lastName":new FormControl("")
    })
   }

   registerReactive(){
     console.log(this.myFormGroup.controls['firstName'].value + this.myFormGroup.controls['lastName'].value);
   }

  ngOnInit(): void {
  }

}
