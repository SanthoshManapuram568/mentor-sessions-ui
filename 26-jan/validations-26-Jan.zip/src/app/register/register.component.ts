import { Component, OnInit } from '@angular/core';
import { flush } from '@angular/core/testing';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  name1 : string="";
  year : number = new Date().getFullYear();
  passwordNotMatched : boolean = false;
  myFormGroup : FormGroup;

  constructor(formBuilder : FormBuilder,public router :Router) {
    this.myFormGroup= formBuilder.group({
      "firstName":new FormControl("",[Validators.required]),
      "lastName":new FormControl("",[Validators.required]),
      "password":new FormControl("",[Validators.required]),
      "repassword":new FormControl("",[Validators.required]),
      "email":new FormControl("",[Validators.required,Validators.email]),
      "contact":new FormControl("",[Validators.required]),
    })
   }

//contact as only numbers
//fname lname shoul not contain numbers and special char

   emailValidation(email : HTMLInputElement){
    if(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(email.value)){
      console.log("valid");
    }else{
      console.log("invalid")
    }
   }

   passwordValidation(password:HTMLInputElement){
     //password no space REGEX //
    if(password.value.length!=0){
      if(password.value.length>=6&&password.value.length<=12){
        console.log("passed");
      }else{
        console.log("failed");
      }
    }else{
      console.log("empty")
    }
   }

   rePasswordValidation(password:HTMLInputElement,repassword:HTMLInputElement){
     console.log(password.value)
     console.log(repassword.value)
    if(password.value==repassword.value){
      this.passwordNotMatched = false;
      console.log("matched")
    }else{
      this.passwordNotMatched = true;
      console.log("notmatched")
    }
    if(repassword.value.length==0){
      this.passwordNotMatched= false;
    }
   }
   

   registerReactive(){
     //if condition to check that every validiation is passe/true
     console.log(this.myFormGroup.controls['firstName'].value +"\n"+ this.myFormGroup.controls['lastName'].value+"\n"+this.myFormGroup.controls['password'].value+"\n" +this.myFormGroup.controls['repassword'].value+"\n" +this.myFormGroup.controls['email'].value +"\n"+this.myFormGroup.controls['contact'].value);
     this.router.navigate(['/login']);
     //alert("page contain")
   }

  ngOnInit(): void {
  }

}
