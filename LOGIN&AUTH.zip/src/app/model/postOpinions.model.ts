export class Opinions {

    opinionID : number;
    username : string;
    opinionText : string;
     

}