import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RegisterUser } from 'src/app/model/register.model';
import { RegisterUserService } from 'src/app/services/register-user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  name1 : string="";
  year : number = new Date().getFullYear();
  passwordValidation : boolean = false;
  prePasswordCheck : boolean = false;
  passwordLength : boolean = false;
  myFormGroup : FormGroup;
  phoneValidation : boolean = false;
  phoneValidationIsNan : boolean = false;
  emailValid : boolean = false;
  submitDisabled : boolean = false;
  showElement : boolean = false;
  showElementSuccess : boolean = false;
  showElementFailure : boolean = false;


  constructor(formBuilder : FormBuilder,public router :Router,public registerService : RegisterUserService) {
    this.myFormGroup= formBuilder.group({
      "firstName":new FormControl("",[Validators.required]),
      "lastName":new FormControl("",[Validators.required]),
      "password":new FormControl("",[Validators.required]),
      "repassword":new FormControl("",[Validators.required]),
      "email":new FormControl("",[Validators.required,Validators.email]),
      "contact":new FormControl("",[Validators.required]),
    })
   }

//contact as only numbers
//fname lname shoul not contain numbers and special char

emailValidation(email : HTMLInputElement){
  if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(email.value))
  {
    this.emailValid = false;
    this.submitDisabled = false;
  }
  else{
    this.emailValid = true;
    this.submitDisabled = true;
  }
  if(email.value.length==0){
    this.emailValid = false 
    this.submitDisabled = false;
  }
}  

   checkPassword(password : HTMLInputElement,rePassword : HTMLInputElement){
    if(password.value.length!=0){
        this.prePasswordCheck = false;
          if(password.value == rePassword.value || rePassword.value.length==0){
              this.passwordValidation = false;
              this.submitDisabled = false;
            }else{
                this.passwordValidation = true;
                this.submitDisabled = true;
            }
          }else{
                this.prePasswordCheck = true;
                this.submitDisabled = true;
    }
    if(rePassword.value.length==0){
      this.prePasswordCheck = false;
      this.submitDisabled = false;
    }
    if(this.prePasswordCheck){
      rePassword.value="";
    }
  }

  // Check prePassword
  checkPrePassword(password : HTMLInputElement){
    if(password.value.length>=6 && password.value.length<=12){
      this.passwordLength = false;
      this.submitDisabled = false;
      }
      else{
        this.passwordLength = true;
        this.submitDisabled = true;
        console.log(this.submitDisabled)
      }
    if(password.value.length!=0){
      this.prePasswordCheck = false;
    }else{
      this.passwordLength = false;
      this.submitDisabled = false;
    }
  } 

   phoneNumberValidaton(number : HTMLInputElement){
    let mobilePattern = "^((\\+91-?)|0)?[0-9]{10}$";
    if(number.value.match(mobilePattern) || number.value.length==0){
      this.phoneValidation = false;
      this.submitDisabled = false;
    }else{
      this.phoneValidation = true;
      this.submitDisabled = true;
    }
    if(!Number.isNaN(parseInt(number.value)) || number.value.length==0 ){
      this.phoneValidationIsNan = false;
    }
    else{
      this.phoneValidationIsNan = true;
      this.submitDisabled = true;
    }
  }
   

   registerReactive(){
    if(this.myFormGroup.controls['firstName'].value.length!=0&&
    this.myFormGroup.controls['lastName'].value.length!=0&&
    this.myFormGroup.controls['password'].value.length!=0&&
    this.myFormGroup.controls['email'].value.length!=0&&
    this.myFormGroup.controls['contact'].value.length!=0){

      console.log("Every field is filled");
      if(this.passwordValidation == false&&
        this.prePasswordCheck == false&&
        this.passwordLength == false&&
        this.phoneValidation == false&&
        this.phoneValidationIsNan == false&&
        this.emailValid == false){
          console.log("NO errors!! calling submit db")
          let user = new RegisterUser(
            this.myFormGroup.controls['firstName'].value,
            this.myFormGroup.controls['lastName'].value,
            this.myFormGroup.controls['password'].value,
            this.myFormGroup.controls['email'].value,
            this.myFormGroup.controls['contact'].value
          );
      
          this.registerService.addNewUser(user).subscribe((successData)=>{
            console.log(successData);
            this.myFormGroup.controls['firstName'].reset();
            this.myFormGroup.controls['lastName'].reset();
            this.myFormGroup.controls['password'].reset();
            this.myFormGroup.controls['email'].reset();
            this.myFormGroup.controls['contact'].reset();
            this.myFormGroup.controls['repassword'].reset();
            this.showElementSuccess = true;
            setTimeout(function() {
              this.showElementSuccess = false;
              this.router.navigate(['/login']);
            }.bind(this), 3000);
           
          },
          failureData =>{
            console.log(failureData);
            this.showElementFailure = true;
            setTimeout(function() {
              this.showElementFailure = false;
            }.bind(this), 5000);
          }
          // => fat arrow fuctions are simlar to lamda 
          );
        }

    }else{
      this.showElement = true;
      setTimeout(function() {
        // console.log('hide');
        this.showElement = false;
      }.bind(this), 3000);
    }
   }

  ngOnInit(): void {
    if(this.myFormGroup.controls['firstName'].value.length==0||
    this.myFormGroup.controls['lastName'].value.length==0||
    this.myFormGroup.controls['password'].value.length==0||
    this.myFormGroup.controls['email'].value.length==0||
    this.myFormGroup.controls['contact'].value.length==0){
      this.submitDisabled = true
    }
  }

}
