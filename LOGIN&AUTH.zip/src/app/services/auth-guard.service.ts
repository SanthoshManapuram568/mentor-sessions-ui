import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService {

  constructor(public router : Router) { }

  canActivate(route : ActivatedRouteSnapshot,state : RouterStateSnapshot){

    if(sessionStorage.getItem("email"))
    return true;
    else{
      this.router.navigate(['/login']);
      return false;
    }
  }

}
