import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RegisterUser } from '../model/register.model';

const URL = "http://localhost:3000/users";

@Injectable({
  providedIn: 'root'
})
export class RegisterUserService {

  constructor(public http : HttpClient) { }

  addNewUser(userDetails : RegisterUser){

    return this.http.post(URL,userDetails);

  }

  

  getAllUsers():any{
    return this.http.get(URL);
  }

}
