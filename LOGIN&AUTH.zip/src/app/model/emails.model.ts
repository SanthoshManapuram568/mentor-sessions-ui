export class Email
{
    userName:string;
}