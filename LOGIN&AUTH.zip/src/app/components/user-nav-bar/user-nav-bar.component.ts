import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-nav-bar',
  templateUrl: './user-nav-bar.component.html',
  styleUrls: ['./user-nav-bar.component.css']
})
export class UserNavBarComponent implements OnInit {

  name : string;

  constructor() { }

  logout(){
    sessionStorage.clear();
  }

  ngOnInit(): void {
  }

}
